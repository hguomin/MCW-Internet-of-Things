﻿using System;

using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Azure.EventHubs;

namespace IoTHubMsgReceiver
{
    class Program
    {
        static private EventHubClient evtHubClient = null;
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            MainAsync().Wait();
        }
        static async Task MainAsync()
        {
            string iotHubBuiltinEventHubConnectionString = "Put your iot hub built in event hub endpoint here.";
            //string iotHubBuiltinEventHubConnectionString = "Endpoint=sb://iothub-ns-smartmeter-2998164-0eb9bb2e95.servicebus.windows.net/;SharedAccessKeyName=iothubowner;SharedAccessKey=flVuvIghloi1Zm7b+hGhTwg9KEPg8ajL9ohFx00njJs=;EntityPath=smartmeter-hub-hgm";//
            
            var tasks = new List<Task>();

            try
            {
                evtHubClient = EventHubClient.CreateFromConnectionString(iotHubBuiltinEventHubConnectionString);
                if(null != evtHubClient)
                {
                    var runtimeInfo = await evtHubClient.GetRuntimeInformationAsync();
                    foreach (var partition in runtimeInfo.PartitionIds)
                    {
                        tasks.Add(Task.Run( async () => {

                            var receiver = evtHubClient.CreateReceiver("$Default", partition, EventPosition.FromEnqueuedTime(DateTime.Now));
                            while (true)
                            {
                                var events = await receiver.ReceiveAsync(100);
                                if(null == events)
                                {
                                    await Task.Delay(1000);
                                    continue;
                                }

                                foreach(EventData eventData in events)
                                {
                                    string msgString = Encoding.UTF8.GetString(eventData.Body.Array);

                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine("Reciverd MSG > {0}", msgString);

                                    Console.ForegroundColor = ConsoleColor.White;
                                    foreach (var prop in eventData.Properties)
                                    {
                                        Console.WriteLine("  {0}: {1}", prop.Key, prop.Value);
                                    }
                                    Console.WriteLine("System properties (set by IoT Hub):");
                                    foreach (var prop in eventData.SystemProperties)
                                    {
                                        Console.WriteLine("  {0}: {1}", prop.Key, prop.Value);
                                    }
                                }
                            }
                        
                        
                        }, CancellationToken.None));
                    }

                    Console.WriteLine("Start to receive iot hub events...");

                    Task.WaitAll(tasks.ToArray());
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }


    }
}
